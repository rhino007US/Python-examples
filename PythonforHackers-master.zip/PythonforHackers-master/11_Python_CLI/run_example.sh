#/bin/bash

python simplified_example.py -u Steve -p Password123 --protocols mysql pop3