#/bin/bash

python hack.py -u Steve Alice -p Password123 MyPass --protocols mysql pop3