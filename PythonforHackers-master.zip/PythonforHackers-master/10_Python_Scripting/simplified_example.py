"""
A simplified version showing the difference

Try running the python file directly from the terminal
run "python simplified_example.py" from bash


Then start Python in its interactive REPL
run "import simplified_example" in python

And see what happens
"""
print("This is a set of instructions")

if __name__ == "__main__":
    print("This is running the instructions")
