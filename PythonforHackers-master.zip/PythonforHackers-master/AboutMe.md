# About Me

## Things you can call me
* Ravin
* Canyon289

## Relevant things
* Keyholder at the best hackerspace ever (23b of course)
* Write a lot of Python for a place I work at and open source. Also fun

## Why this talk?

> Many pentesting tools are written in Python and I thought it would be great to teach others how to write their own.
> Brutespray was a good example, and it included in Kali by default!

## Most importantly!!
* Follow along on your own computer by cloning this repo!
* Questions get rewarded (probably)

## Legal boilerplate
Everything I say is my own opinion  
* I'm not representing anyone or anything in this talk but myself*