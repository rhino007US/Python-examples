"""
A basic python program


Python 2 or 3?
Not a question, Python 2 is outdated, use Python 3
"""
print("Hacking Steve on mysql")

