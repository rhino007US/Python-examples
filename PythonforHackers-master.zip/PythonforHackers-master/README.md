# PythonforHackers
Want to build your own tools like [BruteSpray](https://github.com/x90skysn3k/brutespray)?
Here's the recipe.

# The ingredients
1. Python intepreter
2. Data Types
3. For Loops
4. If Else Nominal Control Flow
5. String Interpolation
6. Exception Control Flow
7. Functions
8. OS Commands and imports
9. File IO
10. Python Scripting
11. Command Line Interface

# How this repo works
Each folder contains a Python script called hack.py. The functionality is built up one piece at a time
* Links to example in Brutespray are provided at the top of each file

## 2020 Update
Link to slide deck [here](https://docs.google.com/presentation/d/1tGv_tX3L6eJzmjoEpX7TpEb2Cv6IBxr8SqceAFRz0_c/edit?usp=sharing)
